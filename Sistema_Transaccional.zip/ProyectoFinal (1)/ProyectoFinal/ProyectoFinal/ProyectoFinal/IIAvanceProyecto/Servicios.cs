﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace IIAvanceProyecto
{
    public partial class Servicios : Form
    {
        public Servicios()
        {
            InitializeComponent();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {
            this.Size = Screen.PrimaryScreen.WorkingArea.Size;
            this.Location = Screen.PrimaryScreen.WorkingArea.Location;
            this.Size = Screen.PrimaryScreen.WorkingArea.Size;
            this.Location = Screen.PrimaryScreen.WorkingArea.Location;
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void button1_Click_1(object sender, EventArgs e)
        {

            SqlConnection conexion = new SqlConnection("server = LAPTOP-IJ8JM21V; database = ProyectoDiseño; integrated security = true");
            conexion.Open();


            String cadena = "insert into Servicios(Código_servicio, Tipo_servicio, Precio_servicio)"
                + "values ('" + textBox1.Text + "','" + textBox2.Text + "','" + textBox3.Text + "')";

            SqlCommand comando = new SqlCommand(cadena, conexion);
            comando.ExecuteNonQuery();

            MessageBox.Show("Los Datos se guardaron");

            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            conexion.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SqlConnection conexion = new SqlConnection("server = LAPTOP-IJ8JM21V; database = ProyectoDiseño; integrated security = true");
            conexion.Open();

            string cadena = "update Servicios set Tipo_servicio='" + textBox2.Text + "'" +
                ", Precio_servicio='" + textBox3.Text + "'" +
                ", where Código_servicio=" + textBox1.Text;


            SqlCommand comando = new SqlCommand(cadena, conexion);
            int canti_modi = comando.ExecuteNonQuery();
            if (canti_modi == 1)
            {
                MessageBox.Show("Se modificaron los Datos");


            }
            else
            {
                MessageBox.Show("No existe el codigo");
                conexion.Close();

                textBox1.Text = "";
                textBox2.Text = "";
                textBox3.Text = "";

            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            SqlConnection conexion = new SqlConnection("server =LAPTOP-IJ8JM21V; database= ProyectoDiseño; integrated security = true;");
            conexion.Open();

            string cadena = "delete from Servicios where Código_servicio=" + textBox1.Text;
            SqlCommand comando = new SqlCommand(cadena, conexion);
            int canti_borrados = comando.ExecuteNonQuery();
            if (canti_borrados == 1)
            {
                MessageBox.Show("El registro fue borrado");
            }
            else
            {
                MessageBox.Show("No existe en el registro");
                textBox1.Text = "";
                textBox2.Text = "";
                textBox3.Text = "";
                conexion.Close();
            }
    }

        private void button4_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

        private void panelTitulo_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panelTitulo_Paint_1(object sender, PaintEventArgs e)
        {

        }
        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();

        [DllImport("user32.DLL", EntryPoint = "SendMessage")]
        private extern static void SendMessage(System.IntPtr hWnd, int wMsg, int wParam, int lParam);
        private void panelTitulo_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0xA1, 0x2, 0);
        }

        private void button7_Click(object sender, EventArgs e)
        {
            SqlConnection conexion = new SqlConnection("server = LAPTOP-IJ8JM21V; database= ProyectoDiseño; integrated security = true;");
            conexion.Open();

            DataTable dt = new DataTable();
            //DataAdapter es un objeto que almacena n numero de DataTables
            SqlDataAdapter adaptador = new SqlDataAdapter("select * from Servicios", conexion);
            //LLena el adaptador con la instruccion sql 
            adaptador.Fill(dt);
            //carga el data
            dataGridView1.DataSource = dt;
            conexion.Close();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}


