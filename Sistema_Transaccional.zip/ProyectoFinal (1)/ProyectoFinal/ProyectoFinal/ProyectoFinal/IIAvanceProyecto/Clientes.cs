﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IIAvanceProyecto
{
    public partial class Clientes : Form
    {
        public Clientes()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            SqlConnection conexion = new SqlConnection("server= LAPTOP-IJ8JM21V; database =  ProyectoDiseño; integrated security = true");
            conexion.Open();
            conexion.Close();
        }
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
          
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {


                SqlConnection conexion = new SqlConnection("server= LAPTOP-IJ8JM21V; database =  ProyectoDiseño; integrated security = true");
                conexion.Open();

                string cadena = "insert into Clientes(identificacion, Numero, Nombre, Provincia, Direccion)" +
                                "values ('" + textBox1.Text + "' ,'" + textBox2.Text + "' , '" + textBox3.Text + "' , '" + comboBox1.Text + "' , '" + textBox4.Text + "')";
                SqlCommand comando = new SqlCommand(cadena, conexion);
                comando.ExecuteNonQuery();

                MessageBox.Show("Los Datos en la Agenda se Guardaron");
                textBox1.Text = "";
                textBox2.Text = "";
                textBox3.Text = "";
                comboBox1.Text = "";
                textBox4.Text = "";

                conexion.Close();
            }
            catch(Exception ex)
            {
                Console.WriteLine("Favor digitar lo debido");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SqlConnection conexion = new SqlConnection("server= LAPTOP-IJ8JM21V; database =  ProyectoDiseño; integrated security = true");
            conexion.Open();

            string cadena = "UPDATE Clientes SET identificacion = '" + textBox1.Text + "'," +
                            " Numero = '" + textBox2.Text + "'," +
                            " Nombre = '" + textBox3.Text + "'," +
                            " Provincia = '" + comboBox1.Text + "'," +
                            " Direccion = '" + textBox4.Text + "'" +
                            " WHERE identificacion = '" + textBox1.Text + "'";

            SqlCommand comando = new SqlCommand(cadena, conexion);
            int canti_modi = comando.ExecuteNonQuery();

            if (canti_modi > 0)
            {
                MessageBox.Show("Se modificaron los Datos del cliente");
            }
            else
            {
                MessageBox.Show("No existe el cliente con la identificación ingresada");
            }

            conexion.Close();
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            comboBox1.Text = "";
            textBox4.Text = "";
        }
    


        private void button3_Click(object sender, EventArgs e)
        {
            SqlConnection conexion = new SqlConnection("server= LAPTOP-IJ8JM21V; database =  ProyectoDiseño; integrated security = true");
            conexion.Open();

            string cadena = "delete from Clientes where identificacion=" + textBox1.Text;
            SqlCommand comando = new SqlCommand(cadena, conexion);

            int canti_borra = comando.ExecuteNonQuery();
            if (canti_borra == 1)
            {
                MessageBox.Show("El cliente fue borrado");
            }
            else
                MessageBox.Show("El cliente ingresado no existe");
            conexion.Close();


        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {
            this.Size = Screen.PrimaryScreen.WorkingArea.Size;
            this.Location = Screen.PrimaryScreen.WorkingArea.Location;
            this.Size = Screen.PrimaryScreen.WorkingArea.Size;
            this.Location = Screen.PrimaryScreen.WorkingArea.Location;
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            SqlConnection conexion = new SqlConnection("server = LAPTOP-IJ8JM21V; database= ProyectoDiseño; integrated security = true;");
            conexion.Open();

            DataTable dt = new DataTable();
            //DataAdapter es un objeto que almacena n numero de DataTables
            SqlDataAdapter adaptador = new SqlDataAdapter("select * from Clientes", conexion);
            //LLena el adaptador con la instruccion sql 
            adaptador.Fill(dt);
            //carga el data
            dataGridView1.DataSource = dt;
            conexion.Close();
        }

        private void PanelTitulo(object sender, PaintEventArgs e)
        {


        }

        private void Panelfondo(object sender, PaintEventArgs e)
        {

        }
        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();

        [DllImport("user32.DLL", EntryPoint = "SendMessage")]
        private extern static void SendMessage(System.IntPtr hWnd, int wMsg, int wParam, int lParam);
        private void panelTitulo_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0xA1, 0x2, 0);
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}


