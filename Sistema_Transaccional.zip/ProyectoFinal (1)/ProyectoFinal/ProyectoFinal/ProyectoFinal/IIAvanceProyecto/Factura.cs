﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics.CodeAnalysis;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace IIAvanceProyecto
{
    public partial class Factura : Form
    {
        private string connectionString;

        public Factura()
        {

            InitializeComponent();

            rellenarComboBox("identificacion", "Clientes", codCliente);
            rellenarComboBox("Código_servicio", "Servicios", codServicio);
            rellenarComboBox("Codigo_producto", "Inventario", codArticulos);


        }
        private void rellenarComboBox(string columna, string tabla, System.Windows.Forms.ComboBox combobox)
        {
            SqlConnection conexion = new SqlConnection($"server=LAPTOP-IJ8JM21V; database = ProyectoDiseño; integrated security = true");
            conexion.Open();
            string cadena = $"select {columna} from {tabla}";
            SqlCommand comando = new SqlCommand(cadena, conexion);
            SqlDataReader lector = comando.ExecuteReader();



            while (lector.Read())
            {
                combobox.Items.Add(lector[$"{columna}"]);
            }
            conexion.Close();
        }


        private void Factura_Load(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button6_Click(object sender, EventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            this.Size = Screen.PrimaryScreen.WorkingArea.Size;
            this.Location = Screen.PrimaryScreen.WorkingArea.Location;
            this.Size = Screen.PrimaryScreen.WorkingArea.Size;
            this.Location = Screen.PrimaryScreen.WorkingArea.Location;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void panelTitulo_Paint(object sender, PaintEventArgs e)
        {

        }
        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();

        [DllImport("user32.DLL", EntryPoint = "SendMessage")]
        private extern static void SendMessage(System.IntPtr hWnd, int wMsg, int wParam, int lParam);
        private void panelTitulo_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0xA1, 0x2, 0);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection conexion = new SqlConnection("server = LAPTOP-IJ8JM21V; database = ProyectoDiseño; integrated security = true");
            conexion.Open();

            String cadena = "insert into Factura(Codigo_Cliente, Lista_servicio, Lista_articulo, Subtotal, Subtotal1,  Total)"
            + "values ('" + codCliente.Text + "','" + codServicio.Text + "','" + codArticulos.Text + "','" + textsubTotal.Text + "','" + textsubTotal2.Text + "','" + textTotal.Text + "')";

            SqlCommand comando = new SqlCommand(cadena, conexion);
            comando.ExecuteNonQuery();

            MessageBox.Show("Los Datos se guardaron");

            codCliente.Text = "";
            codServicio.Text = "";
            codArticulos.Text = "";
            codCliente.Text = "";
            textsubTotal.Text = "";
            textsubTotal2.Text = "";
            textTotal.Text = "";
            conexion.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SqlConnection conexion = new SqlConnection("server = LAPTOP-IJ8JM21V; database = ProyectoDiseño; integrated security = true");
            conexion.Open();

            string cadena = "update Factura set Lista_articulos ='" + codArticulos.Text + "'" +
                            "' Lista_servicio='" + codServicio.Text + "'" +
                            "' Subtotal='" + textsubTotal.Text + "'" +
                            "' Subtotal2= '" + textsubTotal2 + "'" +
                            "' total='" + textTotal.Text + "'" +
                            "' where Codigo_Cliente=" + codCliente.Text;

            SqlCommand comando = new SqlCommand(cadena, conexion);
            int cantidad_modi = comando.ExecuteNonQuery();
            if (cantidad_modi == 1)
            {
                MessageBox.Show("Se ha modificado el inventario");

            }
            else
            {
                MessageBox.Show("No existe el codigo");
                conexion.Close();
                textsubTotal.Text = "";
                codCliente.Text = "";
                codServicio.Text = "";
                codArticulos.Text = "";
                textsubTotal.Text = "";
                textsubTotal2.Text = "";
                textTotal.Text = "";
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            SqlConnection conexion = new SqlConnection("server = LAPTOP-IJ8JM21V; database= ProyectoDiseño; integrated security = true;");
            conexion.Open();

            string cadena = "delete from Factura where Codigo_Cliente=" + codCliente.Text;
            SqlCommand comando = new SqlCommand(cadena, conexion);
            int canti_borrados = comando.ExecuteNonQuery();
            if (canti_borrados == 1)
            {
                MessageBox.Show("El registro fue borrado");
            }
            else
            {
                MessageBox.Show("No existe en el registro");
                textsubTotal.Text = "";
                textsubTotal2.Text = "";
                codArticulos.Text = "";
                codServicio.Text = "";
                codCliente.Text = "";
                textTotal.Text = "";
                conexion.Close();
            }
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            SqlConnection conexion = new SqlConnection("server = LAPTOP-IJ8JM21V; database= ProyectoDiseño; integrated security = true;");
            conexion.Open();

            DataTable dt = new DataTable();
            //DataAdapter es un objeto que almacena n numero de DataTables
            SqlDataAdapter adaptador = new SqlDataAdapter("select * from Factura", conexion);
            //LLena el adaptador con la instruccion sql 
            adaptador.Fill(dt);
            //carga el data
            dataGridView1.DataSource = dt;
            conexion.Close();
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }



       

        private void textsubTotal_TextChanged(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button6_Click_1(object sender, EventArgs e)
        {
            try
            {
                double valor, suma, iva;
                if (!string.IsNullOrWhiteSpace(textsubTotal.Text) && string.IsNullOrWhiteSpace(textsubTotal2.Text))
                {
                    valor = Convert.ToDouble(textsubTotal.Text);
                    iva = valor * 0.13;
                    suma = valor + iva;
                }
                else if (!string.IsNullOrWhiteSpace(textsubTotal.Text) && !string.IsNullOrWhiteSpace(textsubTotal2.Text))
                {
                    double valor1 = Convert.ToDouble(textsubTotal.Text);
                    double valor2 = Convert.ToDouble(textsubTotal2.Text);
                    suma = valor1 + valor2;
                    iva = suma * 0.13;
                }
                else
                {
                    MessageBox.Show("Digite un valor numerico");
                    return;
                }

                textTotal.Text = (suma + iva).ToString("0,00");
            }
            catch (FormatException)
            {
                MessageBox.Show("Digite un valor numerico");
            }
        }

        private void codArticulos_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedCode = codArticulos.SelectedItem.ToString();

            string query = "SELECT Precio FROM Inventario WHERE Codigo_producto = @Codigo_producto";

            using (SqlConnection connection = new SqlConnection("server=LAPTOP-IJ8JM21V; database=ProyectoDiseño; integrated security=true"))
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                command.Parameters.AddWithValue("@Codigo_producto", selectedCode);
                connection.Open();

                object result = command.ExecuteScalar();
                if (result != null && result != DBNull.Value)
                {
                    decimal precio = Convert.ToDecimal(result);
                    textsubTotal2.Text = precio.ToString();
                }
                else
                {
                    textsubTotal2.Text = "Precio no encontrado";
                }
            }
        }
        private void codServicio_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedCode = codServicio.SelectedItem.ToString();

            string query = "SELECT Precio_servicio FROM Servicios WHERE Código_servicio = @Código_servicio";

            using (SqlConnection connection = new SqlConnection("server=LAPTOP-IJ8JM21V; database=ProyectoDiseño; integrated security=true"))
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                command.Parameters.AddWithValue("@Código_servicio", selectedCode);
                connection.Open();

                object result = command.ExecuteScalar();
                if (result != null && result != DBNull.Value)
                {
                    decimal precio = Convert.ToDecimal(result);
                    textsubTotal.Text = precio.ToString();
                }
                else
                {
                    textsubTotal.Text = "Precio no encontrado";
                }
            }
        }
    }
}
