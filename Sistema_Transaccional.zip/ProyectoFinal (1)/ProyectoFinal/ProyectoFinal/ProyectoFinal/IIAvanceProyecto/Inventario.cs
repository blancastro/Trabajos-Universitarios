﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IIAvanceProyecto
{
    public partial class Inventario : Form
    {
        public Inventario()
        {
            InitializeComponent();
        }

        private void Inventario_Load(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button6_Click(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {

            SqlConnection conexion = new SqlConnection("server = LAPTOP-IJ8JM21V; database= ProyectoDiseño; integrated security = true;");
            conexion.Open();

            DataTable dt = new DataTable();
            //DataAdapter es un objeto que almacena n numero de DataTables
            SqlDataAdapter adaptador = new SqlDataAdapter("select * from Inventario", conexion);
            //LLena el adaptador con la instruccion sql 
            adaptador.Fill(dt);
            //carga el data
            dataGridView1.DataSource = dt;
            conexion.Close();

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            SqlConnection conexion = new SqlConnection("server= LAPTOP-IJ8JM21V; database =  ProyectoDiseño; integrated security = true");
            conexion.Open();

            string cadena = "insert into Inventario(Codigo_producto, Tipo_producto, Catidad_producto, Precio)" +
                "values ('" + textBox1.Text + "' ,'" + textBox3.Text + "' , '" + numericUpDown1.Text + "' , '" + textBox4.Text + "')";

            SqlCommand comando = new SqlCommand(cadena, conexion);
            comando.ExecuteNonQuery();

            MessageBox.Show("Los Datos en la Agenda se Guardaron");
            textBox1.Text = "";
            textBox3.Text = "";
            numericUpDown1.Text = "";
            textBox4.Text = "";
            conexion.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SqlConnection conexion = new SqlConnection("server= LAPTOP-IJ8JM21V; database =  ProyectoDiseño; integrated security = true");
            conexion.Open();

            string cadena = "update Inventario set Tipo_producto = '" + textBox3.Text + "'" +
                            ", Catidad_producto = '" + numericUpDown1.Text + "'" +
                            ", Precio = '" + textBox4.Text + "'" +
                            " WHERE Codigo_producto=" + textBox1.Text;

            SqlCommand comando = new SqlCommand(cadena, conexion);
            int cantidad_modi = comando.ExecuteNonQuery();
            if (cantidad_modi == 1)
            {
                MessageBox.Show("Se ha modificado el inventario");

            }
            else
            {
                MessageBox.Show("No existe el codigo");
                conexion.Close();
                textBox1.Text = "";
                textBox3.Text = "";
                numericUpDown1.Text = "";
                textBox4.Text = "";
            }
    }

        private void button3_Click(object sender, EventArgs e)
        {
            SqlConnection conexion = new SqlConnection("server= LAPTOP-IJ8JM21V; database =  ProyectoDiseño; integrated security = true");
            conexion.Open();

            string cadena = "delete from Inventario where Codigo_producto=" + textBox1.Text;
            SqlCommand comando = new SqlCommand(cadena, conexion);
            //esta variable permite detectar cuantos registros fueron borrados
            int cantidad_borrados = comando.ExecuteNonQuery();
            if (cantidad_borrados == 1)
            {
                MessageBox.Show("El registro fue borrado");
            }
            else
                MessageBox.Show("La identificacion no existe");
            textBox1.Text = "";
            textBox3.Text = "";
            numericUpDown1.Text = "";
            textBox4.Text = "";

            conexion.Close();
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Cerrar_Click(object sender, EventArgs e)
        {

            Application.Exit();
        }

        private void Maximizar_Click(object sender, EventArgs e)
        {

            this.Size = Screen.PrimaryScreen.WorkingArea.Size;
            this.Location = Screen.PrimaryScreen.WorkingArea.Location;
            this.Size = Screen.PrimaryScreen.WorkingArea.Size;
            this.Location = Screen.PrimaryScreen.WorkingArea.Location;

        }

        private void Minimizar_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }
        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();

        [DllImport("user32.DLL", EntryPoint = "SendMessage")]
        private extern static void SendMessage(System.IntPtr hWnd, int wMsg, int wParam, int lParam);
        private void panelTitulo_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0xA1, 0x2, 0);
        }

        private void panelTitulo(object sender, PaintEventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {

        }
    }
}
