﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IIAvanceProyecto
{
    public partial class Agenda : Form
    {
        public Agenda()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            SqlConnection conexion = new SqlConnection("server= LAPTOP-IJ8JM21V; database =  ProyectoDiseño; integrated security = true");
            conexion.Open();
            conexion.Close();
        }
      

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {

            SqlConnection conexion = new SqlConnection("server= LAPTOP-IJ8JM21V; database =  ProyectoDiseño; integrated security = true");
            conexion.Open();

            string cadena = "insert into Agenda(Codigo_cliente, Nombre_cliente, Fecha)" +
                "values ('" + textBox1.Text + "' , '" + textBox2.Text + "' , '" + dateTimePicker1.Value.ToString("yyyy-MM-dd") + "')";

            SqlCommand comando = new SqlCommand(cadena, conexion);
            comando.ExecuteNonQuery();

            MessageBox.Show("Los Datos en la Agenda se Guardaron");
            textBox1.Text = "";
            textBox2.Text = "";
            dateTimePicker1.Value = DateTime.Now;
            conexion.Close();


        }

        private void button2_Click_1(object sender, EventArgs e)
        {

            SqlConnection conexion = new SqlConnection("server= LAPTOP-IJ8JM21V; database =  ProyectoDiseño; integrated security = true");
            conexion.Open();

            string cadena = "UPDATE Agenda SET Codigo_cliente = '" + textBox1.Text + "', " +
                           "Nombre_cliente = '" + textBox2.Text + "', " +
                           "Fecha = '" + dateTimePicker1.Value.ToString("yyyy-MM-dd") + "' " +
                           "WHERE Codigo_cliente = '" + textBox1.Text + "'";

            SqlCommand comando = new SqlCommand(cadena, conexion);
            int cantidad_modi = comando.ExecuteNonQuery();
            if (cantidad_modi == 1)
            {
                MessageBox.Show("Se ha modificado la agenda");
            }
            else
            {
                MessageBox.Show("No existe el código");

                conexion.Close();
                textBox1.Text = "";
                textBox2.Text = "";
                dateTimePicker1.Value = DateTime.Now;

            }
    }

        private void button3_Click_1(object sender, EventArgs e)
        {

            SqlConnection conexion = new SqlConnection("server= LAPTOP-IJ8JM21V; database =  ProyectoDiseño; integrated security = true");
            conexion.Open();

            string cadena = "delete from Agenda where codigo_cliente =" + textBox1.Text;
            SqlCommand comando = new SqlCommand(cadena, conexion);

            int cantidad_borrados = comando.ExecuteNonQuery();
            if (cantidad_borrados == 1)
            {
                MessageBox.Show("Se ha borrado la agenda");
            }
            else
                MessageBox.Show("No existe el codigo");
            textBox1.Text = "";
            textBox2.Text = "";
            dateTimePicker1.Value = DateTime.Now;
            conexion.Close();

        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button5_Click(object sender, EventArgs e)
        {

            SqlConnection conexion = new SqlConnection("server =LAPTOP-IJ8JM21V; database= ProyectoDiseño; integrated security = true;");
            conexion.Open();

            DataTable dt = new DataTable();
            //DataAdapter es un objeto que almacena n numero de DataTables
            SqlDataAdapter adaptador = new SqlDataAdapter("select * from Agenda", conexion);
            //LLena el adaptador con la instruccion sql 
            adaptador.Fill(dt);
            //carga el data
            dataGridView1.DataSource = dt;
            conexion.Close();

        }

        private void panelFondo(object sender, PaintEventArgs e)
        {

        }

        private void panelTitulo_Paint(object sender, PaintEventArgs e)
        {

        }
        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();

        [DllImport("user32.DLL", EntryPoint = "SendMessage")]
        private extern static void SendMessage(System.IntPtr hWnd, int wMsg, int wParam, int lParam);
        private void panelTitulo_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0xA1, 0x2, 0);
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            this.Size = Screen.PrimaryScreen.WorkingArea.Size;
            this.Location = Screen.PrimaryScreen.WorkingArea.Location;
            this.Size = Screen.PrimaryScreen.WorkingArea.Size;
            this.Location = Screen.PrimaryScreen.WorkingArea.Location;
        }

        private void Minimizar_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }
    }
}



