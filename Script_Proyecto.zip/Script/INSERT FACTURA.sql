USE [ProyectoDise�o]
GO

INSERT INTO [dbo].[Factura]
           ([Codigo_cliente]
           ,[Lista_servicio]
           ,[Lista_articulo]
           ,[Subtotal]
           ,[Total])
     VALUES
           (<Codigo_cliente, int,>
           ,<Lista_servicio, nvarchar(50),>
           ,<Lista_articulo, nvarchar(50),>
           ,<Subtotal, int,>
           ,<Total, int,>)
GO


