USE [ProyectoDise�o]
GO

DELETE FROM [dbo].[Clientes]
      WHERE <Search Conditions,,>
GO


