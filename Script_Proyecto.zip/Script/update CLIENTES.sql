USE [ProyectoDise�o]
GO

UPDATE [dbo].[Clientes]
   SET [identificacion] = <identificacion, int,>
      ,[Numero] = <Numero, int,>
      ,[Nombre] = <Nombre, nvarchar(50),>
      ,[Provincia] = <Provincia, nvarchar(50),>
      ,[Direccion] = <Direccion, nvarchar(50),>
 WHERE <Search Conditions,,>
GO


