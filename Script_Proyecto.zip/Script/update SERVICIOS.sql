USE [ProyectoDise�o]
GO

UPDATE [dbo].[Servicios]
   SET [C�digo_servicio] = <C�digo_servicio, int,>
      ,[Tipo_servicio] = <Tipo_servicio, nvarchar(50),>
      ,[Precio_servicio] = <Precio_servicio, nchar(10),>
 WHERE <Search Conditions,,>
GO


