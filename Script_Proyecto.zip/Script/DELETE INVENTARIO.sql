USE [ProyectoDise�o]
GO

DELETE FROM [dbo].[Inventario]
      WHERE <Search Conditions,,>
GO


