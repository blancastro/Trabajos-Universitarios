USE [ProyectoDise�o]
GO

INSERT INTO [dbo].[Clientes]
           ([identificacion]
           ,[Numero]
           ,[Nombre]
           ,[Provincia]
           ,[Direccion])
     VALUES
           (<identificacion, int,>
           ,<Numero, int,>
           ,<Nombre, nvarchar(50),>
           ,<Provincia, nvarchar(50),>
           ,<Direccion, nvarchar(50),>)
GO


