USE [ProyectoDise�o]
GO

INSERT INTO [dbo].[Agenda]
           ([Codigo_cliente]
           ,[Nombre_cliente]
           ,[Fecha])
     VALUES
           (<Codigo_cliente, int,>
           ,<Nombre_cliente, nvarchar(20),>
           ,<Fecha, date,>)
GO


