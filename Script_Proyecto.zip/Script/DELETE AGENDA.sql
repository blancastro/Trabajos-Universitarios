USE [ProyectoDise�o]
GO

DELETE FROM [dbo].[Agenda]
      WHERE <Search Conditions,,>
GO


