USE [ProyectoDise�o]
GO

SELECT [Codigo_producto]
      ,[Tipo_producto]
      ,[Cantidad_producto]
      ,[Precio]
  FROM [dbo].[Inventario]

GO


