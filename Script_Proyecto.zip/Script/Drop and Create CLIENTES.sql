USE [ProyectoDise�o]
GO

/****** Object:  Table [dbo].[Clientes]    Script Date: 20/7/2023 00:00:31 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Clientes]') AND type in (N'U'))
DROP TABLE [dbo].[Clientes]
GO

/****** Object:  Table [dbo].[Clientes]    Script Date: 20/7/2023 00:00:31 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Clientes](
	[identificacion] [int] NOT NULL,
	[Numero] [int] NOT NULL,
	[Nombre] [nvarchar](50) NOT NULL,
	[Provincia] [nvarchar](50) NOT NULL,
	[Direccion] [nvarchar](50) NOT NULL
) ON [PRIMARY]
GO


