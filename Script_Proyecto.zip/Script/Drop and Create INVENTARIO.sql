USE [ProyectoDise�o]
GO

/****** Object:  Table [dbo].[Inventario]    Script Date: 20/7/2023 00:07:03 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Inventario]') AND type in (N'U'))
DROP TABLE [dbo].[Inventario]
GO

/****** Object:  Table [dbo].[Inventario]    Script Date: 20/7/2023 00:07:03 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Inventario](
	[Codigo_producto] [nvarchar](50)  NOT NULL,
	[Tipo_producto] [nvarchar](50) NOT NULL,
	[Catidad_producto] [nvarchar](50)  NOT NULL,
	[Precio] [nvarchar](50)  NOT NULL
) ON [PRIMARY]
GO


