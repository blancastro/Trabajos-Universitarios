USE [ProyectoDise�o]
GO

/****** Object:  Table [dbo].[Factura]    Script Date: 20/7/2023 00:11:46 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Factura](
	[Codigo_cliente] [int] NOT NULL,
	[Lista_servicio] [nvarchar](50) NOT NULL,
	[Lista_articulo] [nvarchar](50) NOT NULL,
	[Subtotal] [int] NOT NULL,
	[Total] [int] NOT NULL
) ON [PRIMARY]
GO


