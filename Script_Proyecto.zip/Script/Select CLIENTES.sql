USE [ProyectoDise�o]
GO

SELECT [identificacion]
      ,[Numero]
      ,[Nombre]
      ,[Provincia]
      ,[Direccion]
  FROM [dbo].[Clientes]

GO


