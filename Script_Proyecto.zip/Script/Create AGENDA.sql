USE [ProyectoDise�o]
GO

/****** Object:  Table [dbo].[Agenda]    Script Date: 19/7/2023 23:56:01 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Agenda](
	[Codigo_cliente] [int] NOT NULL,
	[Nombre_cliente] [nvarchar](20) NOT NULL,
	[Fecha] [date] NOT NULL
) ON [PRIMARY]
GO


