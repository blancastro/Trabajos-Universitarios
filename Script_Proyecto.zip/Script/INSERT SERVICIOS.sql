USE [ProyectoDise�o]
GO

INSERT INTO [dbo].[Servicios]
           ([C�digo_servicio]
           ,[Tipo_servicio]
           ,[Precio_servicio])
     VALUES
           (<C�digo_servicio, int,>
           ,<Tipo_servicio, nvarchar(50),>
           ,<Precio_servicio, nchar(10),>)
GO


