USE [ProyectoDise�o]
GO

UPDATE [dbo].[Inventario]
   SET [Codigo_producto] = <Codigo_producto, int,>
      ,[Tipo_producto] = <Tipo_producto, nvarchar(50),>
      ,[Cantidad_producto] = <Cantidad_producto, int,>
      ,[Precio] = <Precio, int,>
 WHERE <Search Conditions,,>
GO


