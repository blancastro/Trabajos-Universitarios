USE [ProyectoDise�o]
GO

DELETE FROM [dbo].[Servicios]
      WHERE <Search Conditions,,>
GO


