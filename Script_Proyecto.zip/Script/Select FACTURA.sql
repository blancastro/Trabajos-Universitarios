USE [ProyectoDise�o]
GO

SELECT [Codigo_cliente]
      ,[Lista_servicio]
      ,[Lista_articulo]
      ,[Subtotal]
      ,[Total]
  FROM [dbo].[Factura]

GO


