USE [ProyectoDise�o]
GO

DELETE FROM [dbo].[Factura]
      WHERE <Search Conditions,,>
GO


