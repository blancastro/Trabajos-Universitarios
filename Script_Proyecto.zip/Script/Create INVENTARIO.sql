USE [ProyectoDise�o]
GO

/****** Object:  Table [dbo].[Inventario]    Script Date: 20/7/2023 00:11:26 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Inventario](
	[Codigo_producto] [int] NOT NULL,
	[Tipo_producto] [nvarchar](50) NOT NULL,
	[Cantidad_producto] [int] NOT NULL,
	[Precio] [int] NOT NULL
) ON [PRIMARY]
GO


