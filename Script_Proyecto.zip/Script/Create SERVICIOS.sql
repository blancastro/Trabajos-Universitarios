USE [ProyectoDise�o]
GO

/****** Object:  Table [dbo].[Servicios]    Script Date: 20/7/2023 00:11:12 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Servicios](
	[C�digo_servicio] [int] NOT NULL,
	[Tipo_servicio] [nvarchar](50) NOT NULL,
	[Precio_servicio] [nchar](10) NOT NULL
) ON [PRIMARY]
GO


