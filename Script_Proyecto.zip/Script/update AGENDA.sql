USE [ProyectoDise�o]
GO

UPDATE [dbo].[Agenda]
   SET [Codigo_cliente] = <Codigo_cliente, int,>
      ,[Nombre_cliente] = <Nombre_cliente, nvarchar(20),>
      ,[Fecha] = <Fecha, date,>
 WHERE <Search Conditions,,>
GO


