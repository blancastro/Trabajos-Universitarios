USE [ProyectoDise�o]
GO

UPDATE [dbo].[Factura]
   SET [Codigo_cliente] = <Codigo_cliente, int,>
      ,[Lista_servicio] = <Lista_servicio, nvarchar(50),>
      ,[Lista_articulo] = <Lista_articulo, nvarchar(50),>
      ,[Subtotal] = <Subtotal, int,>
      ,[Total] = <Total, int,>
 WHERE <Search Conditions,,>
GO


