USE [ProyectoDise�o]
GO

INSERT INTO [dbo].[Inventario]
           ([Codigo_producto]
           ,[Tipo_producto]
           ,[Cantidad_producto]
           ,[Precio])
     VALUES
           (<Codigo_producto, int,>
           ,<Tipo_producto, nvarchar(50),>
           ,<Cantidad_producto, int,>
           ,<Precio, int,>)
GO


