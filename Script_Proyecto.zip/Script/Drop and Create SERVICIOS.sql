USE [ProyectoDise�o]
GO

/****** Object:  Table [dbo].[Servicios]    Script Date: 20/7/2023 00:09:14 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Servicios]') AND type in (N'U'))
DROP TABLE [dbo].[Servicios]
GO

/****** Object:  Table [dbo].[Servicios]    Script Date: 20/7/2023 00:09:14 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Servicios](
	[C�digo_servicio] [int] NOT NULL,
	[Tipo_servicio] [nvarchar](50) NOT NULL,
	[Precio_servicio] [nchar](10) NOT NULL
) ON [PRIMARY]
GO


