USE [ProyectoDise�o]
GO

SELECT [C�digo_servicio]
      ,[Tipo_servicio]
      ,[Precio_servicio]
  FROM [dbo].[Servicios]

GO


